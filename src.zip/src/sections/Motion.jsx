import { useState, useRef, useEffect } from "react";
import "./Motion.css";
import { DRIVE_VIDEOS, drivePreviewUrl, driveThumbUrl } from "../utils/drive";

const MotionModal = ({ video, onClose }) => (
  <div className="motion-modal-overlay" onClick={onClose}>
    <button className="motion-modal-close" onClick={onClose}>✕</button>
    <div className="motion-modal-inner" onClick={(e) => e.stopPropagation()}>
      {video.type === "drive" ? (
        <iframe
          src={drivePreviewUrl(video.link)}
          title={video.title}
          allow="autoplay; fullscreen"
          allowFullScreen
          frameBorder="0"
        />
      ) : video.type === "youtube" ? (
        <iframe
          src={`https://www.youtube.com/embed/${video.youtubeId}?autoplay=1`}
          title={video.title}
          allow="autoplay; encrypted-media; picture-in-picture"
          allowFullScreen
          frameBorder="0"
        />
      ) : (
        <video src={video.src} controls autoPlay playsInline />
      )}
    </div>
  </div>
);

// Hover popup only on devices with a real mouse and enough width
const canHoverPreview = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(hover: hover) and (min-width: 900px)").matches;

const HOVER_DELAY_MS = 350; // small wait so the popup does not open while the mouse just passes by

// The player shown inside the hover popup
const PreviewPlayer = ({ video }) => {
  if (video.type === "drive") {
    return (
      <iframe
        src={drivePreviewUrl(video.link)}
        title={video.title}
        allow="autoplay; fullscreen"
        allowFullScreen
        frameBorder="0"
      />
    );
  }
  if (video.type === "youtube") {
    return (
      <iframe
        src={`https://www.youtube.com/embed/${video.youtubeId}?autoplay=1&mute=1`}
        title={video.title}
        allow="autoplay; encrypted-media; picture-in-picture"
        allowFullScreen
        frameBorder="0"
      />
    );
  }
  return <video src={video.src} controls autoPlay muted loop playsInline />;
};

const MotionCard = ({ video, index, onOpen }) => {
  const videoRef = useRef(null);
  const timer = useRef(null);
  const [hovered, setHovered] = useState(false);
  const [preview, setPreview] = useState(false);

  const handleEnter = () => {
    setHovered(true);
    if (video.type === "local" && videoRef.current) videoRef.current.play().catch(() => {});
    if (canHoverPreview()) {
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setPreview(true), HOVER_DELAY_MS);
    }
  };
  const handleLeave = () => {
    setHovered(false);
    clearTimeout(timer.current);
    setPreview(false);
    if (video.type === "local" && videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  };

  useEffect(() => () => clearTimeout(timer.current), []);

  const openFull = () => {
    clearTimeout(timer.current);
    setPreview(false);
    onOpen(video);
  };

  return (
    <div
      className={`motion-card motion-card--col${index % 3}`}
      onClick={openFull}
      onMouseEnter={handleEnter}
      onMouseLeave={handleLeave}
    >
      <div className="motion-thumb">
        {video.type === "drive" ? (
          <img
            src={driveThumbUrl(video.link)}
            alt={video.title}
            className="motion-thumb-img"
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={(e) => { e.currentTarget.style.visibility = "hidden"; }}
          />
        ) : video.type === "youtube" ? (
          <img src={`https://img.youtube.com/vi/${video.youtubeId}/hqdefault.jpg`} alt={video.title} className="motion-thumb-img" />
        ) : (
          <video ref={videoRef} src={video.src} className="motion-thumb-video" muted loop playsInline preload="metadata" />
        )}
        <div className={`motion-play-overlay ${hovered ? "motion-play-overlay--hidden" : ""}`}>
          <span className="play-icon">▶</span>
        </div>
      </div>
      <p className="motion-title">{video.title}</p>
      <p className="motion-tool">{video.tool}</p>

      {preview && (
        <div className="motion-hover-popup" onClick={(e) => e.stopPropagation()}>
          <div className="motion-hover-player">
            <PreviewPlayer video={video} />
          </div>
          <button type="button" className="motion-hover-expand" onClick={openFull}>
            Full screen <span aria-hidden="true">⤢</span>
          </button>
        </div>
      )}
    </div>
  );
};

const PosterLightbox = ({ src, onClose }) => (
  <div className="motion-modal-overlay" onClick={onClose}>
    <button className="motion-modal-close" onClick={onClose}>✕</button>
    <img src={src} alt="Poster" className="motion-poster-full" onClick={(e) => e.stopPropagation()} />
  </div>
);

const motionWorks = [
  { id: 1, title: "Trainex — Intro Video", tool: "After Effects", type: "drive", link: DRIVE_VIDEOS.trainexIntro },
  { id: 2, title: "Voyd — Logo Animation", tool: "After Effects", type: "drive", link: DRIVE_VIDEOS.voydLogo },
  { id: 3, title: "Trainex — Promotional Video 1", tool: "Premiere Pro", type: "drive", link: DRIVE_VIDEOS.promo1 },
  { id: 4, title: "Trainex — Promotional Video 2", tool: "Premiere Pro", type: "drive", link: DRIVE_VIDEOS.promo2 },
  { id: 5, title: "Trainex — Promotional Video 3", tool: "Premiere Pro", type: "drive", link: DRIVE_VIDEOS.promo3 },
  { id: 6, title: "Voyd — Services Video", tool: "Premiere Pro", type: "youtube", youtubeId: "ZL5FCKvg6AE" },
];

const posters = ["Poster1", "Poster2", "Poster3", "Poster4", "Poster5", "Poster6", "Poster7", "Poster8"];

const Motion = () => {
  const [openVideo, setOpenVideo] = useState(null);
  const [openPoster, setOpenPoster] = useState(null);

  return (
    <section className="motion-section" id="motion">
      <div className="section-wrap">
        <div className="motion-header">
          <div className="motion-text-block">
            <p className="section-eyebrow">Beyond Design</p>
            <h2 className="section-heading motion-heading">
              Motion, video &amp; <span className="accent">marketing</span> too
            </h2>
            <p className="motion-intro">
              Design is where I start, not where I stop. I edit the videos, animate the logos, and
              design the posters that go with them — so the brand shows up complete everywhere it
              needs to, not just on screen.
            </p>
          </div>

          <div className="motion-avatar-block">
            <img
              src="/assets/avatar-point.png"
              alt="Ajay pointing at his creative work"
              className="motion-avatar-big"
            />
          </div>
        </div>

        <div className="motion-container">
          <h3 className="motion-subheading">Motion &amp; Video</h3>
          <div className="motion-grid">
            {motionWorks.map((video, i) => (
              <MotionCard key={video.id} video={video} index={i} onOpen={setOpenVideo} />
            ))}
          </div>

          <h3 className="motion-subheading motion-subheading--posters">Posters &amp; Social Media Design</h3>
          <p className="motion-poster-intro">
            Marketing visuals designed in Photoshop for course launches, announcements, and brand awareness.
          </p>
          <div className="motion-poster-grid">
            {posters.map((name, i) => (
              <div
                key={name}
                className="motion-poster-card"
                onClick={() => setOpenPoster(`/assets/${name}.jpg`)}
              >
                <img src={`/assets/${name}.jpg`} alt={`Poster ${i + 1}`} className="motion-poster-img" />
                <div className="motion-poster-overlay"><span>View</span></div>
              </div>
            ))}
          </div>

          <div className="motion-tools-row">
            <span className="motion-tool-badge">After Effects</span>
            <span className="motion-tool-badge">Premiere Pro</span>
            <span className="motion-tool-badge">Photoshop</span>
          </div>
        </div>
      </div>

      {openVideo && <MotionModal video={openVideo} onClose={() => setOpenVideo(null)} />}
      {openPoster && <PosterLightbox src={openPoster} onClose={() => setOpenPoster(null)} />}
    </section>
  );
};

export default Motion;