import Hero from "../sections/Hero";
import Work from "../sections/Work";
import About from "../sections/About";
import Timeline from "../sections/Timeline";
import Skills from "../sections/Skills";
import Award from "../sections/Award";
import Motion from "../sections/Motion";
import Contact from "../sections/Contact";
import NextSectionHint from "../components/NextSectionHint";
import PageEffects from "../components/PageEffects";

const Home = () => {
  return (
    <>
      <PageEffects />
      <NextSectionHint />
      <Hero />
      <About />
      <Work />
      <Timeline />
      <Skills />
      <Award />
      <Motion />
      <Contact />
    </>
  );
};

export default Home;